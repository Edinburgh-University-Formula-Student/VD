%%%%%%%%%%%%%%%%%%%%% Tyre Force Calculator Program %%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% To be integrated with laptime simulator for evaluating handing
%%%%%%% performance and conrol
% July 2026
% Ubaida Friekh, VD

%%% This program makes use of ISO 8855 coordinate axis convention, which
%%% defines the following:
% X forward positive
% Y left positive
% Z up positive
% Inclination angle right lean positive
% Slip angle right turn positive
% Steer angle left turn positive
% Roll, pitch and yaw follow the right hand rule --> Pitch & Yaw ACW
% positive, Roll CW positive

g = 9.81; % m/s^2

% Parameter Definitions - Setup
Front_Lift_Coefficient = 1.5;
Rear_Lift_Coefficient = 1.8;
%%% Lift Coefficients depend on body slip angle and may be changed to
%%% account for this

% Front and rear motion ratios are functions of wheel travel but are taken
% as constants here
Front_Motion_Ratio = 0.6;
Rear_Motion_Ratio = 0.6;

% Vehicle Dimensions
Track_Width = 1.00; %m
Wheelbase = 1.56; %m
Vehicle_Frontal_Area = 1.1; % m^2 - placeholder

% Mass Centre Coordinates and weights
Sprung_Mass = 240.465; %kg
Front_Unsprung_Mass = 20.335; %kg
Rear_Unsprung_Mass = 19.76; %kg
Vehicle_Mass = Sprung_Mass + Front_Unsprung_Mass + Rear_Unsprung_Mass; %kg

Centre_of_Gravity = [0.811 0.500 0.280]; %m
Sprung_Mass_Centre = [0.7985 0.50183 0.2732]; %m
Front_Unsprung_Mass_Centre = [0.00047121 0.500 0.2656]; %m
Rear_Unsprung_Mass_Centre = [1.5588 0.500 0.2908]; %m

Vehicle_Weight = Vehicle_Mass*9.81; %N
Sprung_Weight = Sprung_Mass*9.81; %N
Front_Unsprung_Weight = Front_Unsprung_Mass*9.81; %N
Rear_Unsprung_Weight = Rear_Unsprung_Mass*9.81; %N

%%% Suspension Stiffnesses
Tyre_Rate = 200000; %N/m FSAE Tyre Test Consortium value = 717 lbs/in for Hoosier 25B 20.5-7-13 at 12psi - change according to setup
Front_Spring_Stiffness = 30000; %NM ROBERTO VALUE
Rear_Spring_Stiffness = 40000; %NM ROBERTO VALUE

Front_Brake_Bias = 0.60; %%% /100 percent

%%% Test limits
Operating_Velocities = linspace(30,30,1); % m/s
deltas = linspace(-20,20,41); %deg
betas = linspace(-10,10,21); %deg
Longitudinal_Accelerations = linspace(-0.5,0.5,3); %g's

addpath('C:/FS/EUFS Internship/MATLAB Programs/EUFS_Tyre_Force_Calculator_Simulation/MFeval/MFeval');
savepath;

%%% Tire Specific Parameters
tire = mfeval.readTIR('C:/FS/EUFS Internship/MATLAB Programs/Edinburgh-University-Formula-Student VD main Tyre Simulation/Tire Models/16x7.5-10-7.tir');
Pressure = 12; %psi
Pressure = Pressure * 6894.76; % Pa - conversion factor

%%% Simulation Settings
Number_of_Rows = numel(Operating_Velocities) * numel(deltas) * numel(betas) * numel(Longitudinal_Accelerations);
results = zeros(Number_of_Rows,10); %%% Results in the form [V Delta Beta Ay Ax N FL FR RL RR]

max_Iteration = 1000;
row = 0;

initial_Guess = 0.2; % Initial Ay guess in g's
tol = 0.001;
relax = 0.1;

%%% Longitudinal Settings
traction = false;
braking = false;
coasting = false;

%%% Suspension geometry for each state is defined based on pre-populated
%%% lookup table which relates each lateral+longitudinal acceleration
%%% combination to roll and pitch angles based on roll and pitch stiffness

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%% DEFINE PITCH AND ROLL SWEEP DATA %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Geometry data is stored in a flattened Ay x Ax grid. The
%%% scatteredInterpolant function allows us to interpolate within the grid
%%% given both Ay and Ax values to obtain the desired geometry. These
%%% interpolants are called as, for example, F.Roll_Angles(Ax,Ay), i.e. as
%%% a function
F.Roll_Angles = scatteredInterpolant([states.Ax]',[states.Ay]',[states.roll]','linear','none');
F.Pitch_Angles = scatteredInterpolant([states.Ax]',[states.Ay]',[states.pitch]','linear','none');

F.FL_Camber = scatteredInterpolant([states.Ax]',[states.Ay]',[states.FL_camber]','linear','none');
F.FR_Camber = scatteredInterpolant([states.Ax]',[states.Ay]',[states.FR_camber]','linear','none');
F.RL_Camber = scatteredInterpolant([states.Ax]',[states.Ay]',[states.RL_camber]','linear','none');
F.RR_Camber = scatteredInterpolant([states.Ax]',[states.Ay]',[states.RR_camber]','linear','none');

F.FL_Toe = scatteredInterpolant([states.Ax]',[states.Ay]',[states.FL_toe]','linear','none');
F.FR_Toe = scatteredInterpolant([states.Ax]',[states.Ay]',[states.FR_toe]','linear','none');
F.RL_Toe = scatteredInterpolant([states.Ax]',[states.Ay]',[states.RL_toe]','linear','none');
F.RR_Toe = scatteredInterpolant([states.Ax]',[states.Ay]',[states.RR_toe]','linear','none');

F.Front_RC = scatteredInterpolant([states.Ax]',[states.Ay]',[states.Front_RC]','linear','none');
F.Rear_RC = scatteredInterpolant([states.Ax]',[states.Ay]',[states.Rear_RC]','linear','none');

F.FL_Contact_Patches = scatteredInterpolant([states.Ax]',[states.Ay]',[states.FL_Contact_Patches]','linear','none');
F.FR_Contact_Patches = scatteredInterpolant([states.Ax]',[states.Ay]',[states.FR_Contact_Patches]','linear','none');
F.RL_Contact_Patches = scatteredInterpolant([states.Ax]',[states.Ay]',[states.RL_Contact_Patches]','linear','none');
F.RR_Contact_Patches = scatteredInterpolant([states.Ax]',[states.Ay]',[states.RR_Contact_Patches]','linear','none');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% Obtain Result Matrix for Yaw Moment Diagram %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for iv = 1:numel(Operating_Velocities) % Sweep across all operational velocities
    Velocity = Operating_Velocities(iv);

    for iax = 1:numel(Longitudinal_Accelerations)
        Longitudinal_Acceleration = Longitudinal_Accelerations(iax);

        if Longitudinal_Acceleration > 0
            traction = true;
            braking = false;
            coasting = false;
            Total_Traction_Force = Vehicle_Weight*Longitudinal_Acceleration;
            RL_Traction_Force = Total_Traction_Force/2;
            RR_Traction_Force = Total_Traction_Force/2;

        elseif Longitudinal_Acceleration < 0
            traction = false;
            braking = true;
            coasting = false;
            Total_Braking_Force = Vehicle_Weight*Longitudinal_Acceleration;
            Front_Braking_Force = Total_Braking_Force * Front_Brake_Bias;
            Rear_Braking_Force = Total_Braking_Force*(1-Front_Brake_Bias);
            FL_Braking_Force = Front_Braking_Force / 2;
            FR_Braking_Force = Front_Braking_Force / 2;
            RL_Braking_Force = Rear_Braking_Force / 2;
            RR_Braking_Force = Rear_Braking_Force / 2;
        else
            traction = false;
            braking = false;
            coasting = true;
        end

        for id = 1:numel(deltas) % Sweep across all operating steering angles
            delta = deltas(id)*pi/180; % Convert steer angle in sweep to radians

            for ib = 1:numel(betas) % Sweep across all physical body slip angles
                beta = betas(ib)*pi/180; % Convert sideslip angle in sweep to radians

                Lateral_Acceleration = initial_Guess;
                row = row + 1

                for k = 1:max_Iteration

                    Front_Left_Contact_Patch = F.FL_Contact_Patches(Longitudinal_Acceleration,Lateral_Acceleration);
                    Front_Right_Contact_Patch = F.FR_Contact_Patches(Longitudinal_Acceleration,Lateral_Acceleration);
                    Rear_Left_Contact_Patch = F.RL_Contact_Patches(Longitudinal_Acceleration,Lateral_Acceleration);
                    Rear_Right_Contact_Patch = F.RR_Contact_Patches(Longitudinal_Acceleration,Lateral_Acceleration);

                    %%% Interpolation to extract geometry corresponding to
                    %%% given longitudinal and lateral acceleration
                    %%% combination.

                    Roll_Angle = F.Roll_Angles(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180; %%% Acquire roll angle through interpolation to obtain inclination angle
                    Pitch_Angle = F.Pitch_Angles(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;

                    FL_camber = F.FL_Camber(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;
                    FR_camber = F.FR_Camber(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;
                    RL_camber = F.RL_Camber(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;
                    RR_camber = F.RR_Camber(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;

                    FL_Toe = F.FL_Toe(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;
                    FR_Toe = F.FR_Toe(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;
                    RL_Toe = F.RL_Toe(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;
                    RR_Toe = F.RR_Toe(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;

                    Front_Roll_Centre_Height = F.Front_RC(Longitudinal_Acceleration,Lateral_Acceleration);
                    Rear_Roll_Centre_Height = F.Rear_RC(Longitudinal_Acceleration,Lateral_Acceleration);

                    Sprung_Centre_Perpendicular_NRA = define_Roll_Axis_Distance(Front_Roll_Centre_Height, ...
                        Rear_Roll_Centre_Height,Sprung_Mass_Centre(1),Sprung_Mass_Centre(3),Wheelbase);

                    Front_Roll_Rate = (Front_Spring_Stiffness*Front_Motion_Ratio^2*Track_Width^2*Tyre_Rate)/(2*(Front_Spring_Stiffness*Front_Motion_Ratio^2+Tyre_Rate)); %Nm/rad
                    Rear_Roll_Rate  = (Rear_Spring_Stiffness*Rear_Motion_Ratio^2*Track_Width^2*Tyre_Rate)/(2*(Rear_Spring_Stiffness*Rear_Motion_Ratio^2+Tyre_Rate)); %Nm/rad

                    Vertical_Wheel_Loads = Compute_Vertical_Wheel_Loads_Aero(Velocity,Vehicle_Weight,Centre_of_Gravity, Wheelbase, Track_Width, ...
                        Lateral_Acceleration, Longitudinal_Acceleration, Sprung_Weight, Sprung_Mass_Centre, ...
                        Front_Unsprung_Weight,Rear_Unsprung_Weight,Front_Unsprung_Mass_Centre,Rear_Unsprung_Mass_Centre,...
                        Front_Roll_Centre_Height, Rear_Roll_Centre_Height, Sprung_Centre_Perpendicular_NRA, ...
                        Front_Roll_Rate, Rear_Roll_Rate, Front_Lift_Coefficient, Rear_Lift_Coefficient,Vehicle_Frontal_Area);

                    for i = 1:numel(Vertical_Wheel_Loads)
                            if Vertical_Wheel_Loads(i) < 0
                                Vertical_Wheel_Loads(i) = 0; %N - correction for unphysical lifting of inside wheels at the extremes
                            end
                    end

                    disp(Vertical_Wheel_Loads)

                    Yaw_Rate = Lateral_Acceleration*g/Velocity;

                    %%% Slip angle calculation assumes toe is clockwise
                    %%% positive, if toe is defined according to FSAE
                    %%% convention of inwards positive, different
                    %%% adjustments will need to be made per-wheel
                    FL_Slip_Angle = beta + Centre_of_Gravity(1)*Yaw_Rate/Velocity - delta - FL_Toe;
                    FR_Slip_Angle = beta + Centre_of_Gravity(1)*Yaw_Rate/Velocity - delta - FR_Toe;
                    RL_Slip_Angle = beta - (Wheelbase-Centre_of_Gravity(1))*Yaw_Rate/Velocity - RL_Toe;
                    RR_Slip_Angle = beta - (Wheelbase-Centre_of_Gravity(1))*Yaw_Rate/Velocity - RR_Toe;

                    Slip_Angles_deg = [FL_Slip_Angle FR_Slip_Angle RL_Slip_Angle RR_Slip_Angle]*180/pi;

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    %%% Inclination angle calculation from camber angles %%%
                    FL_Inclination_Angle = Roll_Angle - FL_camber;
                    FR_Inclination_Angle = Roll_Angle + FR_camber;
                    RL_Inclination_Angle = Roll_Angle - RL_camber;
                    RR_Inclination_Angle = Roll_Angle + RR_camber;
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    %%% Store Magic Formula parameters as 4x1 vectors
                    %%% (corresponding to four wheel loads)
                    Slip_Angles = [FL_Slip_Angle ; FR_Slip_Angle ; RL_Slip_Angle ; RR_Slip_Angle]; % Slip angles
                    Inclination_Angles = [FL_Inclination_Angle ; FR_Inclination_Angle ; RL_Inclination_Angle ; RR_Inclination_Angle]; % Inclination Angles
                    phit = zeros(4,1); % Turn slips, taken as 0 (i.e. infinite turn radius) as an initial approximation
                    Vx = Velocity.*ones(4,1); % Longitudinal Velocity, taken as equal for all wheels
                    P = Pressure.*ones(4,1); % Pressure in Pascals

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    %%%%%%%%%%% Determining Slip Ratio Values %%%%%%%%%%%%%
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    if coasting == true
                        Slip_Ratios = zeros(4,1);

                    elseif traction == true
                        kappa_FL = 0;
                        kappa_FR = 0;

                        RL_Difference = @(kappa_RL) get_Fx(tire,Vertical_Wheel_Loads(3),kappa_RL,Slip_Angles(3),...
                            Inclination_Angles(3),phit(3),Vx(3),P(3)) - RL_Traction_Force;
                        kappa_RL = fzero(RL_Difference,0.2);

                        RR_Difference = @(kappa_RR) get_Fx(tire,Vertical_Wheel_Loads(4),kappa_RR,Slip_Angles(4),...
                            Inclination_Angles(4),phit(4),Vx(4),P(4)) - RR_Traction_Force;
                        kappa_RR = fzero(RR_Difference,0.2);

                        Slip_Ratios = [kappa_FL ; kappa_FR ; kappa_RL ; kappa_RR];

                    elseif braking == true
                        FL_Difference = @(kappa_FL) get_Fx(tire,Vertical_Wheel_Loads(1),kappa_FL,Slip_Angles(1),...
                            Inclination_Angles(1),phit(1),Vx(1),P(1)) - FL_Braking_Force;
                        kappa_FL = fzero(FL_Difference,-0.2);

                        FR_Difference = @(kappa_FR) get_Fx(tire,Vertical_Wheel_Loads(2),kappa_FR,Slip_Angles(2),...
                            Inclination_Angles(2),phit(2),Vx(2),P(2)) - FR_Braking_Force;
                        kappa_FR = fzero(FR_Difference,-0.2);

                        RL_Difference = @(kappa_RL) get_Fx(tire,Vertical_Wheel_Loads(3),kappa_RL,Slip_Angles(3),...
                            Inclination_Angles(3),phit(3),Vx(3),P(3)) - RL_Braking_Force;
                        kappa_RL = fzero(RL_Difference,-0.2);

                        RR_Difference = @(kappa_RR) get_Fx(tire,Vertical_Wheel_Loads(4),kappa_RR,Slip_Angles(4),...
                            Inclination_Angles(4),phit(4),Vx(4),P(4)) - RR_Braking_Force;
                        kappa_RR = fzero(RR_Difference,-0.2);

                        Slip_Ratios = [kappa_FL ; kappa_FR ; kappa_RL ; kappa_RR];
                    end

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    %%% Call Magic Formula Function for four tyre loads
                    out = mfeval(tire,[Vertical_Wheel_Loads,Slip_Ratios,Slip_Angles,Inclination_Angles,phit,Vx,P],111);

                    %%% Store longitudinal and lateral forces
                    Longitudinal_Wheel_Forces = out(:,1);
                    Lateral_Wheel_Forces = out(:,2);

                    Total_Lateral_Force = sum(Lateral_Wheel_Forces);
                    Ay_New = Total_Lateral_Force/(Vehicle_Mass*g);

                    if isnan(Ay_New)
                        disp('Ay is not a number')
                        break
                    end

                    if abs(Ay_New-Lateral_Acceleration) < tol
                        Lateral_Acceleration = Ay_New;
                        Front_Left_Contact_Patch = F.FL_Contact_Patches(Longitudinal_Acceleration,Lateral_Acceleration);
                        Front_Right_Contact_Patch = F.FR_Contact_Patches(Longitudinal_Acceleration,Lateral_Acceleration);
                        Rear_Left_Contact_Patch = F.RL_Contact_Patches(Longitudinal_Acceleration,Lateral_Acceleration);
                        Rear_Right_Contact_Patch = F.RR_Contact_Patches(Longitudinal_Acceleration,Lateral_Acceleration);

                        %%% Interpolation to extract geometry corresponding to
                        %%% given longitudinal and lateral acceleration
                        %%% combination.

                        Roll_Angle = F.Roll_Angles(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180; %%% Acquire roll angle through interpolation to obtain inclination angle
                        Pitch_Angle = F.Pitch_Angles(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;

                        FL_camber = F.FL_Camber(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;
                        FR_camber = F.FR_Camber(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;
                        RL_camber = F.RL_Camber(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;
                        RR_camber = F.RR_Camber(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;

                        FL_Toe = F.FL_Toe(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;
                        FR_Toe = F.FR_Toe(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;
                        RL_Toe = F.RL_Toe(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;
                        RR_Toe = F.RR_Toe(Longitudinal_Acceleration,Lateral_Acceleration) * pi/180;

                        Front_Roll_Centre_Height = F.Front_RC(Longitudinal_Acceleration,Lateral_Acceleration);
                        Rear_Roll_Centre_Height = F.Rear_RC(Longitudinal_Acceleration,Lateral_Acceleration);

                        Sprung_Centre_Perpendicular_NRA = define_Roll_Axis_Distance(Front_Roll_Centre_Height, ...
                            Rear_Roll_Centre_Height,Sprung_Mass_Centre(1),Sprung_Mass_Centre(3),Wheelbase);

                        Front_Roll_Rate = (Front_Spring_Stiffness*Front_Motion_Ratio^2*Track_Width^2*Tyre_Rate)/(2*(Front_Spring_Stiffness*Front_Motion_Ratio^2+Tyre_Rate)); %Nm/rad
                        Rear_Roll_Rate  = (Rear_Spring_Stiffness*Rear_Motion_Ratio^2*Track_Width^2*Tyre_Rate)/(2*(Rear_Spring_Stiffness*Rear_Motion_Ratio^2+Tyre_Rate)); %Nm/rad

                        Vertical_Wheel_Loads = Compute_Vertical_Wheel_Loads_Aero(Velocity,Vehicle_Weight,Centre_of_Gravity, Wheelbase, Track_Width, ...
                            Lateral_Acceleration, Longitudinal_Acceleration, Sprung_Weight, Sprung_Mass_Centre, ...
                            Front_Unsprung_Weight,Rear_Unsprung_Weight,Front_Unsprung_Mass_Centre,Rear_Unsprung_Mass_Centre,...
                            Front_Roll_Centre_Height, Rear_Roll_Centre_Height, Sprung_Centre_Perpendicular_NRA, ...
                            Front_Roll_Rate, Rear_Roll_Rate, Front_Lift_Coefficient, Rear_Lift_Coefficient,Vehicle_Frontal_Area);
                    
                        for i = 1:numel(Vertical_Wheel_Loads)
                            if Vertical_Wheel_Loads(i) < 0
                                Vertical_Wheel_Loads(i) = 0; %N - correction for unphysical lifting of inside wheels at the extremes
                            end
                        end
                      
                        disp(Vertical_Wheel_Loads)

                        Yaw_Rate = Lateral_Acceleration*g/Velocity;

                        %%% Slip angle calculation assumes toe is clockwise
                        %%% positive, if toe is defined according to FSAE
                        %%% convention of inwards positive, different
                        %%% adjustments will need to be made per-wheel
                        FL_Slip_Angle = beta + Centre_of_Gravity(1)*Yaw_Rate/Velocity - delta - FL_Toe;
                        FR_Slip_Angle = beta + Centre_of_Gravity(1)*Yaw_Rate/Velocity - delta - FR_Toe;
                        RL_Slip_Angle = beta - (Wheelbase-Centre_of_Gravity(1))*Yaw_Rate/Velocity - RL_Toe;
                        RR_Slip_Angle = beta - (Wheelbase-Centre_of_Gravity(1))*Yaw_Rate/Velocity - RR_Toe;

                        Slip_Angles_deg = [FL_Slip_Angle FR_Slip_Angle RL_Slip_Angle RR_Slip_Angle]*180/pi;

                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        %%% Inclination angle calculation from camber angles %%%
                        FL_Inclination_Angle = Roll_Angle - FL_camber;
                        FR_Inclination_Angle = Roll_Angle + FR_camber;
                        RL_Inclination_Angle = Roll_Angle - RL_camber;
                        RR_Inclination_Angle = Roll_Angle + RR_camber;
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                        %%% Store Magic Formula parameters as 4x1 vectors
                        %%% (corresponding to four wheel loads)
                        Slip_Angles = [FL_Slip_Angle ; FR_Slip_Angle ; RL_Slip_Angle ; RR_Slip_Angle]; % Slip angles
                        Inclination_Angles = [FL_Inclination_Angle ; FR_Inclination_Angle ; RL_Inclination_Angle ; RR_Inclination_Angle]; % Inclination Angles
                        phit = zeros(4,1); % Turn slips, taken as 0 (i.e. infinite turn radius) as an initial approximation
                        Vx = Velocity.*ones(4,1); % Longitudinal Velocity, taken as equal for all wheels
                        P = Pressure.*ones(4,1); % Pressure in Pascals

                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        %%%%%%%%%%% Determining Slip Ratio Values %%%%%%%%%%%%%
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        if coasting == true
                            Slip_Ratios = zeros(4,1);

                        elseif traction == true
                            kappa_FL = 0;
                            kappa_FR = 0;

                            RL_Difference = @(kappa_RL) get_Fx(tire,Vertical_Wheel_Loads(3),kappa_RL,Slip_Angles(3),...
                                Inclination_Angles(3),phit(3),Vx(3),P(3)) - RL_Traction_Force;
                            kappa_RL = fzero(RL_Difference,0.2);

                            RR_Difference = @(kappa_RR) get_Fx(tire,Vertical_Wheel_Loads(4),kappa_RR,Slip_Angles(4),...
                                Inclination_Angles(4),phit(4),Vx(4),P(4)) - RR_Traction_Force;
                            kappa_RR = fzero(RR_Difference,0.2);

                            Slip_Ratios = [kappa_FL ; kappa_FR ; kappa_RL ; kappa_RR];

                        elseif braking == true
                            FL_Difference = @(kappa_FL) get_Fx(tire,Vertical_Wheel_Loads(1),kappa_FL,Slip_Angles(1),...
                                Inclination_Angles(1),phit(1),Vx(1),P(1)) - FL_Braking_Force;
                            kappa_FL = fzero(FL_Difference,-0.2);

                            FR_Difference = @(kappa_FR) get_Fx(tire,Vertical_Wheel_Loads(2),kappa_FR,Slip_Angles(2),...
                                Inclination_Angles(2),phit(2),Vx(2),P(2)) - FR_Braking_Force;
                            kappa_FR = fzero(FR_Difference,-0.2);

                            RL_Difference = @(kappa_RL) get_Fx(tire,Vertical_Wheel_Loads(3),kappa_RL,Slip_Angles(3),...
                                Inclination_Angles(3),phit(3),Vx(3),P(3)) - RL_Braking_Force;
                            kappa_RL = fzero(RL_Difference,-0.2);

                            RR_Difference = @(kappa_RR) get_Fx(tire,Vertical_Wheel_Loads(4),kappa_RR,Slip_Angles(4),...
                                Inclination_Angles(4),phit(4),Vx(4),P(4)) - RR_Braking_Force;
                            kappa_RR = fzero(RR_Difference,-0.2);

                            Slip_Ratios = [kappa_FL ; kappa_FR ; kappa_RL ; kappa_RR];
                        end

                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                        %%% Call Magic Formula Function for four tyre loads
                        out = mfeval(tire,[Vertical_Wheel_Loads,Slip_Ratios,Slip_Angles,Inclination_Angles,phit,Vx,P],111);

                        %%% Store longitudinal and lateral forces
                        Longitudinal_Wheel_Forces = out(:,1);
                        Lateral_Wheel_Forces = out(:,2);
                        break % k loop (lateral acceleration loop)
                    else
                        Lateral_Acceleration = Lateral_Acceleration + relax*(Ay_New-Lateral_Acceleration);
                    end

                end % k (lateral acceleration loop)

                FL_Lateral = Lateral_Wheel_Forces(1)
                FR_Lateral = Lateral_Wheel_Forces(2)
                RL_Lateral = Lateral_Wheel_Forces(3)
                RR_Lateral = Lateral_Wheel_Forces(4)

                Yaw_Moment = (FL_Lateral + FR_Lateral)*Centre_of_Gravity(1)...
                    + (Longitudinal_Wheel_Forces(1) + Longitudinal_Wheel_Forces(2))*sin(delta)*Centre_of_Gravity(1)...
                    - (RL_Lateral + RR_Lateral) * (Wheelbase - Centre_of_Gravity(1));

                results(row,:) = [Velocity Longitudinal_Acceleration deltas(id) betas(ib) Lateral_Acceleration Yaw_Moment FL_Lateral FR_Lateral RL_Lateral RR_Lateral];
                disp(results(row,:))

            end % ib

        end % id

    end % iax

end % iv

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%% Plot Yaw Moment Diagrams %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for iv = 1:numel(Operating_Velocities) % Sweep across all operational velocities
    V = Operating_Velocities(iv);
    for iax = 1:numel(Longitudinal_Accelerations)
        Ax = Longitudinal_Accelerations(iax);
            figure('Color','w','Position',[100 100 800 550]); ax = gca;
            title(sprintf('C_N Against Lateral Acceleration for V = %.1f m/s',V));
            ylabel('C_N = N/Wl');
            xlabel('Ay');
            grid on;
            hold on;

            %%% Plot constant steering angle lines

            for id = 1:numel(deltas)
                delta = deltas(id);
                delta_line = results(results(:,1) == V & results(:,3) == delta & results(:,2) == Ax,:);
                C_Na = delta_line(:,6)/(Vehicle_Weight*Wheelbase);
                A_ya = delta_line(:,5);

                plot(ax,A_ya, C_Na,'r', 'LineWidth', 2*(delta==0)+0.5, 'DisplayName', sprintf('Delta = %.1f',delta));
                if mod(id+(numel(deltas)-1)/5-1,(numel(deltas)-1)/5) == 0 || delta == 0
                    text(ax,A_ya(end),C_Na(end),sprintf('\\delta=%.0f\\circ',delta));
                end
            end

            %%% PLot constant body slip angle lines

            for ib = 1:numel(betas)
                beta = betas(ib);
                beta_line = results(results(:,1) == V & results(:,4) == beta & results(:,2) == Ax,:);
                C_NB = beta_line(:,6)/(Vehicle_Weight*Wheelbase);
                A_yB = beta_line(:,5);

                plot(ax,A_yB, C_NB,'b','LineWidth', 2*(beta==0)+0.5, 'DisplayName', sprintf('Beta = %.1f',beta));
                if mod(ib+(numel(deltas)-1)/5-1,(numel(betas)-1)/5) == 0 || beta == 0
                    text(ax,A_yB(end),C_NB(end),sprintf('\\beta=%.0f\\circ',beta));
                end
            end

            x_limit = xlim(ax);
            xlim(ax,x_limit + [-0.12 0.12]*diff(x_limit)); %%% Widen the x axis by 12% in both directions
            yline(ax, 0, 'w-', 'LineWidth', 1);
            hold off;
    end
end